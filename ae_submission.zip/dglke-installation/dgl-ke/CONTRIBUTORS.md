# Contributors of DGL-KE

* [Zhichen Jiang](https://github.com/sherry-1001): Add a profiler to MXNet KGE models.
