# pylint
echo 'Ignore checking code style of python codes...'
#python3 -m pylint --reports=y -v --rcfile=tests/lint/pylintrc python/dglke || exit 1
