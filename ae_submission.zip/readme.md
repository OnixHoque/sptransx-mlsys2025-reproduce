# Artefact Evaluation Reproduction for "SparseTransX: Efficient Training of Translation-Based Knowledge Graph Embeddings Using Sparse Matrix Operations", MLSys 2025.

This repository contains artifacts and workflows to reproduce experiments from the MLSys 2025 paper by Md Saidul Hoque Anik and Ariful Azad. The scripts will produce the table depicted as Figure 7 of the paper for the _FB15K_ dataset.

| **SparseTransX: Efficient Training of Translation-Based Knowledge Graph Embeddings Using Sparse Matrix Operations**

# Hardware Prerequisite
The CPU and GPU experiments were run on dedicated CPU/GPU (single) nodes of NERSC Perlmutter. Their configurations are given below. The parameters are set to maximize CPU/GPU utilization. Similar configurations are recommended to reproduce the results.

## For CPU Experiments
`AMD EPYC 7763 (Milan) CPU with 64 cores and 512GB DDR4 memory`

## For GPU Experiments
`1 x NVIDIA A100-SXM4 GPU with 40 GB VRAM`

# Software Prerequisite
